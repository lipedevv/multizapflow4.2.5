declare module "qrcode-terminal";
